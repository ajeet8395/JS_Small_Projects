
function loco() {
    gsap.registerPlugin(ScrollTrigger);

    const locoScroll = new LocomotiveScroll({
        el: document.querySelector("#mobile"),
        smooth: true
    });
    locoScroll.on("scroll", ScrollTrigger.update);

    ScrollTrigger.scrollerProxy("#mobile", {
        scrollTop(value) {
            return arguments.length ? locoScroll.scrollTo(value, 0, 0) : locoScroll.scroll.instance.scroll.y;
        },
        getBoundingClientRect() {
            return { top: 0, left: 0, width: window.innerWidth, height: window.innerHeight };
        },
    });

}
loco();

var tl = gsap.timeline({
    scrollTrigger: {
        trigger: '#mobile-page1',
        start: 'top top',
        // end: '+=100%',
        scrub: 1,
        scroller: '#mobile',
        pin: true,
        onUpdate: function (self) {
            const h1Top = document.querySelector('#mobile-page1>h1').getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            const opacity = .3 + Math.abs(h1Top) / windowHeight;
            document.querySelector('#mobile-page1>h1').style.opacity = opacity;
            const opacity1 = .9 - Math.abs(h1Top) / windowHeight;
            document.querySelector('#mobile-page1>.ovrly1').style.opacity = opacity1;
        }
    }
});

tl.to('#mobile-page1>h1', {
    top: '0%'
});

var tl1 = gsap.timeline({
    scrollTrigger: {
        trigger: '#mobile-page2',
        start: 'top top',
        // end: '+=100%',
        scrub: 1,
        scroller: '#mobile',
        pin: true,
        onUpdate: function (self1) {
            const h12Top = document.querySelector('#mobile-page2>h1').getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            const opacity = .3 + Math.abs(h12Top) / windowHeight;
            document.querySelector('#mobile-page2>h1').style.opacity = opacity;
            const opacity1 = .9 - Math.abs(h12Top) / windowHeight;
            document.querySelector('#mobile-page2>.ovrly2').style.opacity = opacity1;
        }
    }
});

tl1.to('#mobile-page2>h1', {
    top: '0%'
});

var tl3 = gsap.timeline({
    scrollTrigger: {
        trigger: '#mobile-page3',
        start: 'top top',
        // end: '+=100%',
        scrub: 1,
        scroller: '#mobile',
        pin: true,
        onUpdate: function (self2) {
            const h13Top = document.querySelector('#mobile-page3>h1').getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            const opacity = .3 + Math.abs(h13Top) / windowHeight;
            document.querySelector('#mobile-page3>h1').style.opacity = opacity;
            const opacity1 = .9 - Math.abs(h13Top) / windowHeight;
            document.querySelector('#mobile-page3>.ovrly3').style.opacity = opacity1;
        }
    }
});

tl3.to('#mobile-page3>h1', {
    top: '0%'
});
