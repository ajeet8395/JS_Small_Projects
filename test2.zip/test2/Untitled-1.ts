<script>
    let upCount = 0;
let downCount = 1;


function handleScroll(event) {
    if (event.deltaY < 0) {
        upCount++;
        if (downCount > 0) {
            downCount--;
        }
    } else if (event.deltaY > 0) {
        downCount++;
        if (downCount < 0) {
            upCount--;
        }
    }
    updateView();
}

function handleTouch(event) {
    const delta = event.touches[0].clientY - startY;
    if (delta > 0) {
        upCount++;
        if (downCount > 0) {
            downCount--;
        }
    } else {
        downCount++;
        if (upCount > 0) {
            upCount--;
        }
    }
    startY = event.touches[0].clientY;
    updateView();
}

function updateView() {
    const panel1 = document.getElementById('panel1');
    const panel2 = document.getElementById('panel2');
    const panel3 = document.getElementById('panel3');
    const panel4 = document.getElementById('panel4');

    if (downCount < 15) {
        panel1.classList.add('ajopacityz');
        panel2.classList.remove('ajopacityz');
        panel3.classList.remove('ajopacityz');
        panel4.classList.remove('ajopacityz');
        moveH1(panel1, downCount);
    } else if (downCount >= 15 && downCount <= 25) {
        panel1.classList.remove('ajopacityz');
        panel2.classList.add('ajopacityz');
        panel3.classList.remove('ajopacityz');
        panel4.classList.remove('ajopacityz');
        moveH1(panel2, downCount - 15);
    } else if (downCount > 25 && downCount <= 30) {
        panel1.classList.remove('ajopacityz');
        panel2.classList.remove('ajopacityz');
        panel3.classList.add('ajopacityz');
        panel4.classList.remove('ajopacityz');
        moveH1(panel3, downCount - 20);
    } else if (downCount > 30 && downCount <= 32) {
        panel1.classList.remove('ajopacityz');
        panel2.classList.remove('ajopacityz');
        panel3.classList.remove('ajopacityz');
        panel4.classList.add('ajopacityz');
        moveH1(panel3, downCount - 20);
    }
    const newSection = document.getElementById('main');
    const outrmain = document.querySelector('.outrmain');

    if (panel4.classList.contains('ajopacityz')) {
        main.style.display = 'block';
        outrmain.style.maxHeight = '10vh';
    } else {
        main.style.display = 'none';
        outrmain.style.maxHeight = '100vh';
    }
}

function moveH1(panel, downCount) {
    const h1 = panel.querySelector('.ajpanlhed h1');
    const ovrly1 = panel.querySelector('.ovrly1');
    const percentage = downCount * 5;
    let opacity;

    if (percentage <= 40) {
        opacity = 1;
    } else {
        opacity = 1 - ((percentage - 40) / 50);
    }

    h1.style.bottom = (10 + percentage) + '%';
    h1.style.opacity = opacity;
    const opacitybg = 1 - downCount / 10;
    ovrly1.style.opacity = 1 - opacitybg;
}

document.addEventListener("DOMContentLoaded", function () {
    const panel1 = document.getElementById('panel1');
    moveH1(panel1, downCount);
});

// document.addEventListener('wheel', handleMouseWheel);
let startY;
const isMobile = window.innerWidth < 767;
if (isMobile) {
    document.addEventListener('touchstart', function (event) {
        startY = event.touches[0].clientY;
    }, false);
    document.addEventListener('touchmove', handleTouch, false);
} else {
    document.addEventListener('wheel', handleScroll);
}
</script>