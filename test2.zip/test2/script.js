// const panels = document.querySelectorAll('.panel');

// // Initial z-index values
// const zIndexValues = [10, 5, 0];

// // Set initial z-index for each panel
// panels.forEach((panel, index) => {
//     panel.style.zIndex = zIndexValues[index];
// });

// // GSAP ScrollTrigger for smooth scrolling animations
// gsap.registerPlugin(ScrollTrigger);

// panels.forEach((panel, index) => {
//     ScrollTrigger.create({
//         trigger: panel,
//         start: "top top",
//         end: () => "+=" + panel.offsetHeight,
//         pin: true,
//         pinSpacing: false,
//         onEnter: () => {
//             // Shift z-index values to move the panel to the back
//             const newZIndexValues = zIndexValues.slice(index).concat(zIndexValues.slice(0, index));
//             panels.forEach((panel, index) => {
//                 gsap.to(panel, { zIndex: newZIndexValues[index], duration: 0.5 });
//             });
//         },
//         onLeaveBack: () => {
//             // Shift z-index values to move the panel to the front
//             const newZIndexValues = zIndexValues.slice(-index).concat(zIndexValues.slice(0, -index));
//             panels.forEach((panel, index) => {
//                 gsap.to(panel, { zIndex: newZIndexValues[index], duration: 0.5 });
//             });
//         }
//     });
// });



// for scroll opcaity decrease and increase script
// const panels = document.querySelectorAll('.panel');

// panels.forEach((panel, index) => {
//     panel.style.opacity = 1 - (index * 0.3);
// });

// gsap.registerPlugin(ScrollTrigger);

// panels.forEach((panel, index) => {
//     ScrollTrigger.create({
//         trigger: panel,
//         start: 'top center',
//         end: 'bottom center',
//         onEnter: () => {
//             gsap.to(panel, {
//                 opacity: 1,
//                 duration: 0.5
//             });
//         },
//         onLeaveBack: () => {
//             gsap.to(panel, {
//                 opacity: 1 - (index * 0.3),
//                 duration: 0.5
//             });
//         },
//         markers: true 
//     });
// });

 